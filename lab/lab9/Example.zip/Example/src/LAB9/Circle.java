package LAB9;

public class Circle {
}
