package sustech.cs102a.lab8;
public class Circle {
    private double radius;
    private double x;
    private double y;

    public Circle(double radius, double x, double y) {
        this.radius = radius;
        this.x = x;
        this.y = y;
    }

    @Override
    public String toString() {
        return "Circle{" +
                "radius=" + radius +
                ", x=" + x +
                ", y=" + y +
                ", area=" + String.format("%.2f",area()) +
                ", perimeter=" + String.format("%.2f",perimeter()) +
                '}';


    }

    public double area() {
        return getRadius() * getRadius() *Math.PI;
    }
    public double perimeter () {
        return 2*Math.PI* getRadius();
    }


    public double getRadius() {
        return radius;
    }

    public void setRadius(double radius) {
        if (radius > 0) {
            this.radius = radius;
        }
    }

    public double getX() {
        return x;
    }

    public void setX(double x) {
        this.x = x;
    }

    public double getY() {
        return y;
    }

    public void setY(double y) {
        this.y = y;
    }

}
