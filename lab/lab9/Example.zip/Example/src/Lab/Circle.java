package Lab;

public class Circle {
}
